<?php
/**
 * Migration Engine AJAX Handlers
 *
 * @package Edmingle_Tutor_Migration\Admin
 */

namespace ETM\Admin;

use ETM\Includes\ETM_Database;

class Migration_Engine {

	/**
	 * Register hooks.
	 */
	public function register() {
		add_action( 'wp_ajax_etm_migrate_students', array( $this, 'ajax_migrate_students' ) );
		add_action( 'wp_ajax_etm_migrate_courses', array( $this, 'ajax_migrate_courses' ) );
	}

	/**
	 * Helper to send structured response.
	 */
	private function send_progress( $state_key, $state, $stats ) {
		update_option( $state_key, $state );
		wp_send_json_success( array(
			'state' => $state,
			'stats' => $stats,
		) );
	}

	/**
	 * Migrate Students AJAX
	 */
	public function ajax_migrate_students() {
		check_ajax_referer( 'etm_admin_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Permission denied.' );
		}

		$resume = isset( $_POST['resume'] ) && $_POST['resume'] === 'true';
		$state_key = 'etm_migrate_state_students';
		
		$state = get_option( $state_key, array(
			'offset'          => 0,
			'records_migrated'=> 0,
			'total_records'   => 0,
			'status'          => 'idle',
		) );

		if ( ! $resume ) {
			$state['offset'] = 0;
			$state['records_migrated'] = 0;
			$state['total_records'] = ETM_Database::get_total_records( 'edmingle_students' );
			$state['status'] = 'running';
		}

		if ( $state['total_records'] === 0 ) {
			wp_send_json_error( 'No local records found. Please sync students first.' );
		}

		$limit = 50;
		global $wpdb;
		$table = $wpdb->prefix . 'edmingle_students';
		
		// Fetch batch
		$records = $wpdb->get_results( $wpdb->prepare(
			"SELECT * FROM $table ORDER BY id ASC LIMIT %d OFFSET %d",
			$limit, $state['offset']
		) );

		$stats = array(
			'imported' => 0,
			'updated'  => 0,
			'skipped'  => 0,
			'errors'   => 0
		);

		if ( empty( $records ) ) {
			$state['status'] = 'completed';
			$this->send_progress( $state_key, $state, $stats );
		}

		foreach ( $records as $record ) {
			$data = json_decode( $record->json_data, true );
			if ( ! $data ) {
				$stats['errors']++;
				continue;
			}

			// Edmingle specific student data mapping
			$email = isset( $data['email'] ) ? sanitize_email( $data['email'] ) : '';
			$name  = isset( $data['name'] ) ? sanitize_text_field( $data['name'] ) : 'Student ' . $record->edmingle_id;
			
			if ( empty( $email ) ) {
				$email = $record->edmingle_id . '@migrated.edmingle.local';
			}

			// Check if WP user exists
			$user = get_user_by( 'email', $email );
			
			if ( $user ) {
				update_user_meta( $user->ID, '_etm_edmingle_id', $record->edmingle_id );
				$stats['skipped']++;
			} else {
				$password = wp_generate_password( 12, false );
				$user_id = wp_insert_user( array(
					'user_login' => $email,
					'user_email' => $email,
					'user_pass'  => $password,
					'first_name' => $name,
					'role'       => 'subscriber'
				) );

				if ( is_wp_error( $user_id ) ) {
					$stats['errors']++;
				} else {
					update_user_meta( $user_id, '_etm_edmingle_id', $record->edmingle_id );
					$stats['imported']++;
				}
			}
		}

		$state['offset'] += count( $records );
		$state['records_migrated'] += count( $records );
		
		if ( count( $records ) < $limit || $state['records_migrated'] >= $state['total_records'] ) {
			$state['status'] = 'completed';
		} else {
			$state['status'] = 'running';
		}

		$this->send_progress( $state_key, $state, $stats );
	}

	/**
	 * Migrate Courses AJAX
	 */
	public function ajax_migrate_courses() {
		// Implement later
		wp_send_json_error( 'Course migration not implemented yet.' );
	}
}
